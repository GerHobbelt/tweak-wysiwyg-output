Shape Dividers for WYSIWYG Web Builder
This installer will install extra Shape Dividers in the folder My Documents\WYSIWYG Web Builder\system\dividers

LICENSE AGREEMENT
This add-on is not officially supported; it is made available as an extra service for the registered users of WYSIWYG Web Builder that find it useful. It is provided "AS IS" without warranty of any kind, either expressed or implied.

This software may not be sold, rented, redistributed, sublicensed or modified without permission of the author.
This software is provided "AS IS" without warranty of any kind including, but not limited to, warranties of merchantability, fitness for a particular purpose and non-infringement. In no event will Pablo Software Solutions be liable for any direct, indirect, incidental, special, exemplary or consequential damages, including damages for loss of profits, loss or inaccuracy of data, incurred by any person from such person's usage of this application if advised of the possibility of such damages.

